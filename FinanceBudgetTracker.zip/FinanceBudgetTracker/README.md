# Finance Budget Tracker (React Native / Expo)

A demo finance budget tracker built for the assignment requirements:
- Home with Sign Up / Sign In and daily, weekly, monthly report selector
- Admin and Customer demo roles
- Financial analysis dashboard
- Customer profile and edit profile
- Month-wise transactions, filtering and add transaction form
- Overall spending categories and category details
- React Navigation Stack, Bottom Tabs, and Drawer
- Basic form validation and personalized in-app alerts
- Local persistence with AsyncStorage; no backend or database

## Requirements
- Node.js 20.19+ recommended
- npm
- Expo Go compatible with the installed Expo SDK, or an Android emulator

## Install and run
```bash
npm install
npx expo install --fix
npx expo start -c
```
Scan the QR code with Expo Go, or press `a` for an Android emulator.

If you are using an existing Expo project with a different SDK, do not mix dependencies; create a fresh folder from this ZIP first.

## Demo sign-in
- Customer email: `arun@example.com`
- Admin email: `admin@demo.com`
- Demo password: `demo123`

The demo validates email and password format but does not verify credentials against a server. Sign Up creates a local Customer demo session.

## Folder map
- `src/navigation/` contains Stack, Tab and Drawer navigators.
- `src/screens/` contains all app screens.
- `src/components/` contains reusable UI components.
- `src/context/AppContext.js` holds session, transactions, profile, alerts and local persistence.
- `src/data/` contains editable sample data.
- `src/utils/` contains calculations and validation helpers.

## Important notes
1. This is a learning/demo app, not a real banking application.
2. The app uses sample data and local device storage only.
3. The provided Figma URL was not accessible to the generator, so the visual style is a polished finance-app approximation, not a verified 75% match to the exact Figma frames. Compare against exported Figma screenshots and adjust spacing/colors before submission.
4. For a real deployment, add server-side authentication, authorization, and transaction storage.
