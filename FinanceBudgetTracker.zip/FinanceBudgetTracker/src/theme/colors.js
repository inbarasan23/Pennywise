export const colors = {
  background: '#F6F7FB',
  surface: '#FFFFFF',
  primary: '#5146E5',
  primaryDark: '#3930B8',
  text: '#1D2340',
  muted: '#7D839A',
  border: '#E8EAF2',
  green: '#16A878',
  greenLight: '#E4F8F0',
  red: '#E65B65',
  redLight: '#FFF0F1',
  orange: '#F0A23B',
  purpleLight: '#EEECFF',
  blueLight: '#E8F3FF'
};
