import React, { useState } from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { Screen, Heading, Field, Button, Pill, Card } from '../components/UI';
import { colors } from '../theme/colors';
import { useApp } from '../context/AppContext';
import { validateEmail, validatePassword } from '../utils/validation';

export default function SignInScreen({ navigation, route }) {
  const { signIn } = useApp();
  const [role, setRole] = useState(route?.params?.role || 'Customer');
  const [email, setEmail] = useState(role === 'Admin' ? 'admin@demo.com' : 'arun@example.com');
  const [password, setPassword] = useState('demo123');
  const [errors, setErrors] = useState({});
  const submit = () => {
    const next = {};
    if (!validateEmail(email)) next.email = 'Enter a valid email address.';
    if (!validatePassword(password)) next.password = 'Password must contain at least 6 characters.';
    setErrors(next);
    if (Object.keys(next).length) return;
    signIn({ role, email, name: role === 'Admin' ? 'Admin' : 'Arun Kumar' });
  };
  return <Screen>
    <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>← Back</Text></TouchableOpacity>
    <Heading title="Welcome back" subtitle="Sign in to continue to your finance dashboard." />
    <Card>
      <Text style={styles.label}>Sign in as</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}><Pill label="Customer" active={role === 'Customer'} onPress={() => { setRole('Customer'); setEmail('arun@example.com'); }} /><Pill label="Admin" active={role === 'Admin'} onPress={() => { setRole('Admin'); setEmail('admin@demo.com'); }} /></View>
      <Field label="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" error={errors.email} />
      <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry error={errors.password} />
      <Text style={styles.hint}>Demo password: demo123. This is local demo authentication.</Text>
      <Button title={`Sign in as ${role}`} onPress={submit} />
    </Card>
    <View style={styles.bottom}><Text style={styles.muted}>New here? </Text><TouchableOpacity onPress={() => navigation.navigate('SignUp')}><Text style={styles.link}>Create account</Text></TouchableOpacity></View>
  </Screen>;
}
const styles = StyleSheet.create({
  back: { color: colors.primary, fontWeight: '700', marginBottom: 8 },
  label: { color: colors.text, fontWeight: '700', marginBottom: 10 },
  hint: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: -4, marginBottom: 8 },
  bottom: { flexDirection: 'row', justifyContent: 'center', padding: 10 },
  muted: { color: colors.muted },
  link: { color: colors.primary, fontWeight: '800' }
});
