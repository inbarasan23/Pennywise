import React, { useState } from 'react';
import { Text } from 'react-native';
import { Screen, Heading, Card, Field, Button } from '../components/UI';
import { useApp } from '../context/AppContext';
import { validateEmail, validatePhone } from '../utils/validation';
import { colors } from '../theme/colors';

export default function EditProfileScreen({ navigation }) {
  const { profile, saveProfile } = useApp();
  const [name, setName] = useState(profile.name || '');
  const [email, setEmail] = useState(profile.email || '');
  const [phone, setPhone] = useState(profile.phone || '');
  const [errors, setErrors] = useState({});
  const submit = () => {
    const next = {};
    if (!name.trim()) next.name = 'Name is required.';
    if (!validateEmail(email)) next.email = 'Enter a valid email address.';
    if (phone && !validatePhone(phone)) next.phone = 'Enter a valid phone number.';
    setErrors(next);
    if (Object.keys(next).length) return;
    saveProfile({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    navigation.goBack();
  };
  return <Screen>
    <Heading title="Edit profile" subtitle="Your changes are saved on this device." />
    <Card>
      <Field label="Full name" value={name} onChangeText={setName} error={errors.name} />
      <Field label="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" error={errors.email} />
      <Field label="Phone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" error={errors.phone} />
      <Button title="Save changes" onPress={submit} />
      <Button title="Cancel" variant="secondary" onPress={() => navigation.goBack()} />
      <Text style={{ color: colors.muted, fontSize: 12 }}>No backend is used. Data is persisted locally with AsyncStorage.</Text>
    </Card>
  </Screen>;
}
