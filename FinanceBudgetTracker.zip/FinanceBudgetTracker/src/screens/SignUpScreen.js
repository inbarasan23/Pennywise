import React, { useState } from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import { Screen, Heading, Field, Button, Card } from '../components/UI';
import { colors } from '../theme/colors';
import { useApp } from '../context/AppContext';
import { validateEmail, validatePassword, validatePhone } from '../utils/validation';

export default function SignUpScreen({ navigation }) {
  const { signIn, saveProfile, profile } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState({});
  const submit = () => {
    const next = {};
    if (!name.trim()) next.name = 'Name is required.';
    if (!validateEmail(email)) next.email = 'Enter a valid email address.';
    if (!validatePhone(phone)) next.phone = 'Enter a valid phone number (10–13 digits).';
    if (!validatePassword(password)) next.password = 'Use at least 6 characters.';
    if (password !== confirm) next.confirm = 'Passwords do not match.';
    setErrors(next);
    if (Object.keys(next).length) return;
    saveProfile({ name: name.trim(), email: email.trim(), phone: phone.trim() });
    signIn({ role: 'Customer', email: email.trim(), name: name.trim() });
  };
  return <Screen>
    <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>← Back</Text></TouchableOpacity>
    <Heading title="Create account" subtitle="A few details and you are ready to go." />
    <Card>
      <Field label="Full name" value={name} onChangeText={setName} error={errors.name} />
      <Field label="Email address" value={email} onChangeText={setEmail} keyboardType="email-address" error={errors.email} />
      <Field label="Phone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" error={errors.phone} />
      <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry error={errors.password} />
      <Field label="Confirm password" value={confirm} onChangeText={setConfirm} secureTextEntry error={errors.confirm} />
      <Button title="Create customer account" onPress={submit} />
      <Text style={styles.hint}>Registration is stored locally for this demo; no server is contacted.</Text>
    </Card>
  </Screen>;
}
const styles = StyleSheet.create({ back: { color: colors.primary, fontWeight: '700', marginBottom: 8 }, hint: { color: colors.muted, fontSize: 12, lineHeight: 18, marginTop: 10 } });
