import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, Modal, StyleSheet, TouchableOpacity } from 'react-native';
import { Screen, Heading, Card, Pill, Button, Field, EmptyState } from '../components/UI';
import TransactionItem from '../components/TransactionItem';
import { useApp } from '../context/AppContext';
import { colors } from '../theme/colors';
import { money, totals, monthLabel, sameMonth } from '../utils/calculations';
import { categories } from '../data/categories';

const monthOptions = [-2, -1, 0, 1].map(offset => {
  const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() + offset);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
});

export default function TransactionsScreen() {
  const { transactions, addTransaction } = useApp();
  const [month, setMonth] = useState(monthOptions[2]);
  const [filter, setFilter] = useState('all');
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState('food');
  const [type, setType] = useState('expense');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [error, setError] = useState('');

  const scoped = useMemo(() => transactions.filter(t => sameMonth(t.date, month) && (filter === 'all' || t.type === filter)).sort((a,b) => b.date.localeCompare(a.date)), [transactions, month, filter]);
  const sums = totals(transactions.filter(t => sameMonth(t.date, month)));
  const save = () => {
    const num = Number(amount);
    if (!title.trim()) return setError('Enter a transaction name.');
    if (!Number.isFinite(num) || num <= 0) return setError('Amount must be greater than zero.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return setError('Date must use YYYY-MM-DD.');
    const cat = type === 'income' ? { name: 'Other income', id: 'income' } : categories.find(c => c.id === categoryId);
    addTransaction({ title: title.trim(), amount: num, type, date, categoryId: cat.id, category: cat.name, note: '' });
    setTitle(''); setAmount(''); setError(''); setShowAdd(false);
  };

  return <Screen>
    <Heading title="Transactions" subtitle="Review your money in and out, month by month." right={<TouchableOpacity onPress={() => setShowAdd(true)} style={styles.addBtn}><Text style={styles.addText}>＋ Add</Text></TouchableOpacity>} />
    <View style={styles.months}>{monthOptions.map(m => <Pill key={m} label={monthLabel(m).split(' ')[0].slice(0,3)} active={month === m} onPress={() => setMonth(m)} />)}</View>
    <Text style={styles.monthTitle}>{monthLabel(month)}</Text>
    <View style={styles.summaryRow}><Card style={styles.summaryCard}><Text style={styles.muted}>Income</Text><Text style={[styles.sum, { color: colors.green }]}>{money(sums.income)}</Text></Card><Card style={styles.summaryCard}><Text style={styles.muted}>Expenses</Text><Text style={[styles.sum, { color: colors.red }]}>{money(sums.expenses)}</Text></Card></View>
    <View style={styles.filters}>{[['all','All'],['expense','Expenses'],['income','Income']].map(([key,label]) => <Pill key={key} label={label} active={filter === key} onPress={() => setFilter(key)} />)}</View>
    <Card>{scoped.length ? scoped.map(item => <TransactionItem key={item.id} item={item} />) : <EmptyState title="No transactions yet" subtitle="Try another month or add a transaction." />}</Card>
    <Modal visible={showAdd} transparent animationType="slide" onRequestClose={() => setShowAdd(false)}>
      <View style={styles.modalShade}><View style={styles.modal}>
        <Text style={styles.modalTitle}>Add transaction</Text>
        <View style={styles.filters}><Pill label="Expense" active={type === 'expense'} onPress={() => setType('expense')} /><Pill label="Income" active={type === 'income'} onPress={() => setType('income')} /></View>
        <Field label="Transaction name" value={title} onChangeText={setTitle} />
        <Field label="Amount (₹)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" />
        {type === 'expense' && <View style={{ gap: 8 }}><Text style={styles.muted}>Category</Text><View style={styles.months}>{categories.map(c => <Pill key={c.id} label={c.name} active={categoryId === c.id} onPress={() => setCategoryId(c.id)} />)}</View></View>}
        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} />
        {error ? <Text style={{ color: colors.red, fontSize: 12 }}>{error}</Text> : null}
        <Button title="Save transaction" onPress={save} />
        <Button title="Cancel" variant="secondary" onPress={() => { setShowAdd(false); setError(''); }} />
      </View></View>
    </Modal>
  </Screen>;
}
const styles = StyleSheet.create({
  addBtn: { backgroundColor: colors.primary, paddingHorizontal: 13, paddingVertical: 10, borderRadius: 12 },
  addText: { color: '#FFFFFF', fontWeight: '800' },
  months: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  monthTitle: { color: colors.text, fontSize: 18, fontWeight: '800' },
  summaryRow: { flexDirection: 'row', gap: 10 },
  summaryCard: { flex: 1, padding: 13, borderRadius: 16 },
  muted: { color: colors.muted, fontSize: 12 },
  sum: { fontSize: 17, fontWeight: '900', marginTop: 5 },
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  modalShade: { flex: 1, backgroundColor: '#11132D99', justifyContent: 'flex-end' },
  modal: { backgroundColor: colors.background, padding: 20, borderTopLeftRadius: 24, borderTopRightRadius: 24, gap: 10, maxHeight: '92%' },
  modalTitle: { color: colors.text, fontWeight: '900', fontSize: 21, marginBottom: 3 }
});
