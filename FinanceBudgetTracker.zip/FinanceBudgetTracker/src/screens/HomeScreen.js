import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Screen, Button, Card, Pill } from '../components/UI';
import { colors } from '../theme/colors';
import { useApp } from '../context/AppContext';
import { filterPeriod, totals, money } from '../utils/calculations';

export default function HomeScreen({ navigation }) {
  const { transactions } = useApp();
  const [period, setPeriod] = useState('monthly');
  const report = totals(filterPeriod(transactions, period));
  return <Screen>
    <View style={styles.top}>
      <View><Text style={styles.brand}>pennywise <Text style={{ color: colors.primary }}>●</Text></Text><Text style={styles.welcome}>Your money, made simple.</Text></View>
      <View style={styles.avatar}><Text style={{ fontSize: 24 }}>💸</Text></View>
    </View>
    <View style={styles.hero}>
      <Text style={styles.eyebrow}>PERSONAL FINANCE</Text>
      <Text style={styles.heroTitle}>Take control of your money.</Text>
      <Text style={styles.heroText}>Track spending, understand your habits, and make every rupee count.</Text>
      <View style={styles.heroArt}><Text style={{ fontSize: 50 }}>📈</Text><View style={styles.heroCoin}><Text style={{ fontSize: 24 }}>₹</Text></View></View>
    </View>
    <View style={{ gap: 10 }}>
      <Text style={styles.sectionTitle}>Your reports</Text>
      <View style={styles.pills}>{['daily', 'weekly', 'monthly'].map(p => <Pill key={p} label={p[0].toUpperCase() + p.slice(1)} active={period === p} onPress={() => setPeriod(p)} />)}</View>
      <Card>
        <Text style={styles.reportLabel}>{period[0].toUpperCase() + period.slice(1)} overview</Text>
        <View style={styles.reportRow}><View><Text style={styles.small}>Income</Text><Text style={[styles.amount, { color: colors.green }]}>{money(report.income)}</Text></View><View><Text style={styles.small}>Expenses</Text><Text style={[styles.amount, { color: colors.red }]}>{money(report.expenses)}</Text></View></View>
        <View style={styles.balance}><Text style={styles.small}>Net balance for period</Text><Text style={styles.balanceValue}>{money(report.balance)}</Text></View>
      </Card>
    </View>
    <View style={{ gap: 10 }}>
      <Text style={styles.sectionTitle}>Get started</Text>
      <Button title="Sign In" onPress={() => navigation.navigate('SignIn')} />
      <Button title="Create an account" variant="secondary" onPress={() => navigation.navigate('SignUp')} />
      <TouchableOpacity onPress={() => navigation.navigate('SignIn', { role: 'Admin' })} style={{ padding: 8 }}><Text style={styles.adminLink}>Admin demo sign in →</Text></TouchableOpacity>
    </View>
    <Text style={styles.footer}>Demo app · Sample financial data only</Text>
  </Screen>;
}
const styles = StyleSheet.create({
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  brand: { fontSize: 22, fontWeight: '900', color: colors.text, letterSpacing: -0.7 },
  welcome: { color: colors.muted, marginTop: 4, fontSize: 13 },
  avatar: { width: 48, height: 48, backgroundColor: colors.purpleLight, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  hero: { backgroundColor: '#25204F', borderRadius: 24, padding: 22, minHeight: 225, overflow: 'hidden', gap: 10 },
  eyebrow: { color: '#BDB8FF', fontSize: 10, fontWeight: '800', letterSpacing: 2 },
  heroTitle: { color: '#FFFFFF', fontSize: 27, fontWeight: '900', lineHeight: 32, maxWidth: 240 },
  heroText: { color: '#D7D5F2', fontSize: 13, lineHeight: 19, maxWidth: 245 },
  heroArt: { position: 'absolute', right: 18, bottom: 14, width: 95, height: 95, borderRadius: 48, backgroundColor: '#49428B', alignItems: 'center', justifyContent: 'center' },
  heroCoin: { position: 'absolute', right: 0, top: 0, width: 36, height: 36, borderRadius: 18, backgroundColor: '#B4F1D6', alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { color: colors.text, fontSize: 18, fontWeight: '800' },
  pills: { flexDirection: 'row', gap: 8 },
  reportLabel: { color: colors.muted, fontWeight: '700', fontSize: 12 },
  reportRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  small: { color: colors.muted, fontSize: 12 },
  amount: { fontSize: 19, fontWeight: '800', marginTop: 5 },
  balance: { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 12 },
  balanceValue: { fontSize: 24, fontWeight: '900', color: colors.text, marginTop: 4 },
  adminLink: { color: colors.primary, fontWeight: '700', textAlign: 'center' },
  footer: { textAlign: 'center', color: colors.muted, fontSize: 11, marginTop: 2 }
});
