import React from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import { Screen, Heading, Card, Button } from '../components/UI';
import { useApp } from '../context/AppContext';
import { colors } from '../theme/colors';

export default function ProfileScreen({ navigation }) {
  const { profile, signOut } = useApp();
  return <Screen>
    <Heading title="My profile" subtitle="Manage your personal details." />
    <Card style={styles.profileCard}>
      <View style={styles.avatar}><Text style={{ fontSize: 36 }}>👤</Text></View>
      <Text style={styles.name}>{profile.name}</Text><Text style={styles.email}>{profile.email}</Text>
    </Card>
    <Card>
      <Text style={styles.section}>Personal information</Text>
      <View style={styles.info}><Text style={styles.label}>Full name</Text><Text style={styles.value}>{profile.name}</Text></View>
      <View style={styles.info}><Text style={styles.label}>Email address</Text><Text style={styles.value}>{profile.email}</Text></View>
      <View style={styles.info}><Text style={styles.label}>Phone number</Text><Text style={styles.value}>{profile.phone || 'Not added'}</Text></View>
    </Card>
    <Button title="Edit profile" onPress={() => navigation.getParent()?.getParent()?.navigate('EditProfile')} />
    <Button title="Sign out" variant="secondary" onPress={signOut} />
  </Screen>;
}
const styles = StyleSheet.create({
  profileCard: { alignItems: 'center', paddingVertical: 25 },
  avatar: { width: 82, height: 82, borderRadius: 28, backgroundColor: colors.purpleLight, alignItems: 'center', justifyContent: 'center' },
  name: { color: colors.text, fontSize: 21, fontWeight: '900', marginTop: 8 },
  email: { color: colors.muted, fontSize: 13 },
  section: { color: colors.text, fontSize: 16, fontWeight: '800', marginBottom: 4 },
  info: { paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: colors.border, gap: 4 },
  label: { color: colors.muted, fontSize: 12 },
  value: { color: colors.text, fontWeight: '700', fontSize: 14 }
});
