import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { Screen, Heading, Card, EmptyState } from '../components/UI';
import { useApp } from '../context/AppContext';
import { categories } from '../data/categories';
import { money } from '../utils/calculations';
import TransactionItem from '../components/TransactionItem';
import { colors } from '../theme/colors';

export default function CategoryDetailsScreen({ route }) {
  const { transactions } = useApp();
  const category = categories.find(c => c.id === route?.params?.categoryId) || categories[0];
  const month = new Date().toISOString().slice(0, 7);
  const items = transactions.filter(t => t.categoryId === category.id && t.type === 'expense').sort((a,b) => b.date.localeCompare(a.date));
  const monthlyItems = items.filter(t => t.date.slice(0,7) === month);
  const total = monthlyItems.reduce((sum,t) => sum + Number(t.amount), 0);
  return <Screen>
    <Heading title={category.name} subtitle="Category spending and related transactions." />
    <Card style={[styles.hero, { backgroundColor: category.color, borderColor: category.color }]}>
      <Text style={{ fontSize: 34 }}>{category.icon}</Text>
      <Text style={styles.label}>Spent this month</Text>
      <Text style={styles.total}>{money(total)}</Text>
      <View style={styles.budgetRow}><Text style={styles.label}>Monthly budget</Text><Text style={styles.budget}>{money(category.budget)}</Text></View>
      <View style={styles.track}><View style={[styles.fill, { width: `${Math.min(100, total / category.budget * 100)}%` }]} /></View>
      <Text style={styles.label}>{Math.round(total / category.budget * 100)}% of monthly budget used</Text>
    </Card>
    <Card>
      <Text style={styles.title}>Transactions</Text>
      {items.length ? items.map(item => <TransactionItem key={item.id} item={item} />) : <EmptyState title="Nothing here yet" subtitle="Transactions for this category will appear here." />}
    </Card>
  </Screen>;
}
const styles = StyleSheet.create({
  hero: { gap: 9 },
  label: { color: '#FFFFFFD9', fontSize: 12, fontWeight: '600' },
  total: { color: '#FFFFFF', fontSize: 31, fontWeight: '900' },
  budgetRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  budget: { color: '#FFFFFF', fontWeight: '800' },
  track: { height: 9, borderRadius: 9, backgroundColor: '#FFFFFF55', overflow: 'hidden' },
  fill: { height: 9, borderRadius: 9, backgroundColor: '#FFFFFF' },
  title: { color: colors.text, fontSize: 16, fontWeight: '800' }
});
