import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Screen, Heading, Card, Pill } from '../components/UI';
import { useApp } from '../context/AppContext';
import { filterPeriod, totals, money } from '../utils/calculations';
import { colors } from '../theme/colors';
import TransactionItem from '../components/TransactionItem';

export default function AnalysisScreen() {
  const { transactions, user } = useApp();
  const [period, setPeriod] = useState('monthly');
  const scoped = useMemo(() => filterPeriod(transactions, period), [transactions, period]);
  const total = totals(scoped);
  const expenseItems = scoped.filter(t => t.type === 'expense');
  const grouped = {};
  expenseItems.forEach(t => grouped[t.category] = (grouped[t.category] || 0) + Number(t.amount));
  const groups = Object.entries(grouped).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...groups.map(g => g[1]));
  return <Screen>
    <Heading title="Financial analysis" subtitle={`Hello ${user?.name || user?.role}, here's your ${period} overview.`} />
    <View style={styles.periods}>{['daily', 'weekly', 'monthly'].map(p => <Pill key={p} label={p[0].toUpperCase() + p.slice(1)} active={period === p} onPress={() => setPeriod(p)} />)}</View>
    <Card style={styles.balanceCard}>
      <Text style={styles.cardMuted}>Net balance</Text><Text style={styles.big}>{money(total.balance)}</Text>
      <View style={styles.twoCols}><View><Text style={styles.cardMuted}>Income</Text><Text style={[styles.value, { color: colors.green }]}>{money(total.income)}</Text></View><View><Text style={styles.cardMuted}>Expenses</Text><Text style={[styles.value, { color: colors.red }]}>{money(total.expenses)}</Text></View></View>
    </Card>
    <Card>
      <Text style={styles.cardTitle}>Spending by category</Text>
      {groups.length ? groups.map(([name, amount]) => <View key={name} style={{ gap: 6, marginTop: 8 }}><View style={styles.barLabel}><Text style={styles.catName}>{name}</Text><Text style={styles.catAmount}>{money(amount)}</Text></View><View style={styles.track}><View style={[styles.fill, { width: `${(amount / max) * 100}%` }]} /></View></View>) : <Text style={styles.muted}>No expenses recorded for this period.</Text>}
    </Card>
    <Card>
      <Text style={styles.cardTitle}>Recent activity</Text>
      {scoped.slice(0, 4).map(item => <TransactionItem key={item.id} item={item} />)}
      {!scoped.length && <Text style={styles.muted}>No transactions for this period.</Text>}
    </Card>
  </Screen>;
}
const styles = StyleSheet.create({
  periods: { flexDirection: 'row', gap: 8 },
  balanceCard: { backgroundColor: '#292353', borderColor: '#292353' },
  cardMuted: { color: '#C5C1E8', fontSize: 12 },
  big: { color: '#FFFFFF', fontSize: 30, fontWeight: '900', marginVertical: 4 },
  twoCols: { flexDirection: 'row', gap: 40, borderTopWidth: 1, borderTopColor: '#514B7D', paddingTop: 13, marginTop: 6 },
  value: { fontWeight: '800', fontSize: 16, marginTop: 4 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '800' },
  barLabel: { flexDirection: 'row', justifyContent: 'space-between' },
  catName: { color: colors.text, fontSize: 13, fontWeight: '600' },
  catAmount: { color: colors.text, fontSize: 12, fontWeight: '800' },
  track: { height: 8, borderRadius: 8, backgroundColor: '#F0F1F7', overflow: 'hidden' },
  fill: { height: 8, borderRadius: 8, backgroundColor: colors.primary },
  muted: { color: colors.muted, fontSize: 13 }
});
