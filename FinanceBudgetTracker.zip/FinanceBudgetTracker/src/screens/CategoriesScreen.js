import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Screen, Heading, Card } from '../components/UI';
import { categories } from '../data/categories';
import { useApp } from '../context/AppContext';
import { colors } from '../theme/colors';
import { money } from '../utils/calculations';

export default function CategoriesScreen({ navigation }) {
  const { transactions } = useApp();
  const month = new Date().toISOString().slice(0, 7);
  const monthlyExpenses = transactions.filter(t => t.type === 'expense' && t.date.slice(0,7) === month);
  const total = monthlyExpenses.reduce((sum,t) => sum + Number(t.amount), 0);
  return <Screen>
    <Heading title="Categories" subtitle="See which parts of life your money goes to." />
    <Card style={styles.totalCard}><Text style={styles.totalLabel}>Total categorized spending this month</Text><Text style={styles.total}>{money(total)}</Text><Text style={styles.totalLabel}>{categories.length} spending categories</Text></Card>
    {categories.map(cat => {
      const amount = monthlyExpenses.filter(t => t.categoryId === cat.id).reduce((sum,t) => sum + Number(t.amount), 0);
      const percent = total ? Math.min(100, amount / total * 100) : 0;
      return <TouchableOpacity key={cat.id} activeOpacity={0.8} onPress={() => navigation.navigate('CategoryDetails', { categoryId: cat.id, categoryName: cat.name })}>
        <Card style={styles.catCard}>
          <View style={[styles.catIcon, { backgroundColor: `${cat.color}20` }]}><Text style={{ fontSize: 22 }}>{cat.icon}</Text></View>
          <View style={{ flex: 1, gap: 7 }}>
            <View style={styles.row}><Text style={styles.name}>{cat.name}</Text><Text style={styles.amount}>{money(amount)}</Text></View>
            <View style={styles.track}><View style={[styles.fill, { width: `${percent}%`, backgroundColor: cat.color }]} /></View>
            <Text style={styles.sub}>{money(cat.budget)} monthly budget · {Math.round(percent)}% of spending</Text>
          </View>
          <Text style={styles.chevron}>›</Text>
        </Card>
      </TouchableOpacity>;
    })}
  </Screen>;
}
const styles = StyleSheet.create({
  totalCard: { backgroundColor: colors.primary, borderColor: colors.primary },
  totalLabel: { color: '#DCD9FF', fontSize: 12 },
  total: { color: '#FFFFFF', fontSize: 29, fontWeight: '900', marginVertical: 4 },
  catCard: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 13 },
  catIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', justifyContent: 'space-between', gap: 6 },
  name: { color: colors.text, fontWeight: '800', fontSize: 13, flex: 1 },
  amount: { color: colors.text, fontWeight: '800', fontSize: 13 },
  track: { height: 7, borderRadius: 8, backgroundColor: '#F0F1F7', overflow: 'hidden' },
  fill: { height: 7, borderRadius: 8 },
  sub: { color: colors.muted, fontSize: 10 },
  chevron: { color: colors.muted, fontSize: 25 }
});
