export const money = (amount) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount || 0);

export function totals(transactions) {
  const income = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const expenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + Number(t.amount || 0), 0);
  return { income, expenses, balance: income - expenses };
}

export function sameMonth(dateString, monthKey) {
  return String(dateString || '').slice(0, 7) === monthKey;
}

export function filterPeriod(transactions, period) {
  const now = new Date();
  const start = new Date(now);
  if (period === 'daily') start.setHours(0, 0, 0, 0);
  if (period === 'weekly') start.setDate(now.getDate() - 6);
  if (period === 'monthly') start.setDate(1);
  return transactions.filter(t => {
    const d = new Date(`${t.date}T12:00:00`);
    return d >= start && d <= now;
  });
}

export function monthLabel(key) {
  const [year, month] = key.split('-').map(Number);
  return new Date(year, month - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
}
