import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useApp } from '../context/AppContext';
import HomeScreen from '../screens/HomeScreen';
import SignInScreen from '../screens/SignInScreen';
import SignUpScreen from '../screens/SignUpScreen';
import AdminNavigator from './AdminNavigator';
import CustomerNavigator from './CustomerNavigator';
import CategoryDetailsScreen from '../screens/CategoryDetailsScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import { colors } from '../theme/colors';
import AlertBanner from '../components/AlertBanner';
import { View } from 'react-native';

const Stack = createNativeStackNavigator();

function AppShell({ children }) {
  return <View style={{ flex: 1, backgroundColor: colors.background }}><AlertBanner />{children}</View>;
}

export default function RootNavigator() {
  const { user } = useApp();
  return <NavigationContainer>
    <Stack.Navigator screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }}>
      {!user ? <>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="SignIn" component={SignInScreen} />
        <Stack.Screen name="SignUp" component={SignUpScreen} />
      </> : user.role === 'Admin' ? <>
        <Stack.Screen name="AdminApp" component={AdminNavigator} />
      </> : <>
        <Stack.Screen name="CustomerApp" component={CustomerNavigator} />
        <Stack.Screen name="CategoryDetails" component={CategoryDetailsScreen} options={{ headerShown: true, title: 'Category Details', headerStyle: { backgroundColor: colors.background }, headerTintColor: colors.text }} />
        <Stack.Screen name="EditProfile" component={EditProfileScreen} options={{ headerShown: true, title: 'Edit Profile', headerStyle: { backgroundColor: colors.background }, headerTintColor: colors.text }} />
      </>}
    </Stack.Navigator>
  </NavigationContainer>;
}
