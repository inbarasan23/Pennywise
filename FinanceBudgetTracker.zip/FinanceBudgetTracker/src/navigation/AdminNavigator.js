import React from 'react';
import AppDrawer from './AppDrawer';
export default function AdminNavigator() {
  return <AppDrawer role="Admin" />;
}
