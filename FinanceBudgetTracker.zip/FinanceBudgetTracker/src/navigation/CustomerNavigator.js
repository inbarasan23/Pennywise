import React from 'react';
import AppDrawer from './AppDrawer';
export default function CustomerNavigator() {
  return <AppDrawer role="Customer" />;
}
