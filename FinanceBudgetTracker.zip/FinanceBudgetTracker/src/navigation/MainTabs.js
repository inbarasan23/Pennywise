import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import AnalysisScreen from '../screens/AnalysisScreen';
import TransactionsScreen from '../screens/TransactionsScreen';
import CategoriesScreen from '../screens/CategoriesScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { colors } from '../theme/colors';

const Tab = createBottomTabNavigator();
const icons = { Analysis: '📊', Transactions: '🧾', Categories: '🗂️', Profile: '👤' };

export default function MainTabs({ role }) {
  return <Tab.Navigator screenOptions={({ route }) => ({
    headerShown: false,
    tabBarActiveTintColor: colors.primary,
    tabBarInactiveTintColor: colors.muted,
    tabBarStyle: { height: 64, paddingTop: 7, paddingBottom: 8, borderTopColor: colors.border, backgroundColor: '#FFFFFF' },
    tabBarLabelStyle: { fontSize: 10, fontWeight: '700' },
    tabBarIcon: ({ focused }) => <Text style={{ fontSize: 18, opacity: focused ? 1 : 0.65 }}>{icons[route.name] || '•'}</Text>
  })}>
    <Tab.Screen name="Analysis" component={AnalysisScreen} />
    {role === 'Customer' && <Tab.Screen name="Transactions" component={TransactionsScreen} />}
    {role === 'Customer' && <Tab.Screen name="Categories" component={CategoriesScreen} />}
    {role === 'Customer' && <Tab.Screen name="Profile" component={ProfileScreen} />}
  </Tab.Navigator>;
}
