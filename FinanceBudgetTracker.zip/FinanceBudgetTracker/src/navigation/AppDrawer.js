import React from 'react';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer';
import { View, Text } from 'react-native';
import MainTabs from './MainTabs';
import { useApp } from '../context/AppContext';
import { colors } from '../theme/colors';

const Drawer = createDrawerNavigator();

function CustomDrawer(props) {
  const { user, signOut } = useApp();
  return <DrawerContentScrollView {...props} contentContainerStyle={{ flex: 1 }}>
    <View style={{ padding: 22, backgroundColor: colors.primary, marginBottom: 12 }}>
      <Text style={{ fontSize: 30 }}>💰</Text>
      <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '800', marginTop: 8 }}>{user?.name || user?.role}</Text>
      <Text style={{ color: '#E4E2FF', fontSize: 12, marginTop: 3 }}>{user?.role} account</Text>
    </View>
    <DrawerItemList {...props} />
    <View style={{ flex: 1 }} />
    <DrawerItem label="Sign Out" onPress={signOut} labelStyle={{ color: colors.red, fontWeight: '700' }} />
  </DrawerContentScrollView>;
}

export default function AppDrawer({ role }) {
  return <Drawer.Navigator drawerContent={props => <CustomDrawer {...props} />} screenOptions={{
    headerTitle: 'Finance Tracker',
    headerStyle: { backgroundColor: colors.background },
    headerTintColor: colors.text,
    drawerActiveTintColor: colors.primary,
    drawerLabelStyle: { fontWeight: '700' },
    sceneStyle: { backgroundColor: colors.background }
  }}>
    <Drawer.Screen name="Dashboard" options={{ title: 'Dashboard', drawerLabel: 'Dashboard' }}>{props => <MainTabs role={role} {...props} />}</Drawer.Screen>
  </Drawer.Navigator>;
}
