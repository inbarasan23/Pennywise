const dateDaysAgo = (days) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const initialTransactions = [
  { id: 't1', title: 'Monthly Salary', categoryId: 'income', category: 'Salary', amount: 45000, type: 'income', date: dateDaysAgo(0), note: 'Monthly salary' },
  { id: 't2', title: 'Grocery Shopping', categoryId: 'food', category: 'Food & Dining', amount: 1250, type: 'expense', date: dateDaysAgo(1), note: 'Weekly groceries' },
  { id: 't3', title: 'Cab Ride', categoryId: 'transport', category: 'Transport', amount: 280, type: 'expense', date: dateDaysAgo(2), note: 'Ride to office' },
  { id: 't4', title: 'Electricity Bill', categoryId: 'bills', category: 'Bills & Utilities', amount: 1450, type: 'expense', date: dateDaysAgo(3), note: 'Monthly bill' },
  { id: 't5', title: 'New Shoes', categoryId: 'shopping', category: 'Shopping', amount: 2200, type: 'expense', date: dateDaysAgo(4), note: 'Running shoes' },
  { id: 't6', title: 'Freelance Work', categoryId: 'income', category: 'Freelance', amount: 6500, type: 'income', date: dateDaysAgo(5), note: 'Website work' },
  { id: 't7', title: 'Dinner', categoryId: 'food', category: 'Food & Dining', amount: 780, type: 'expense', date: dateDaysAgo(6), note: 'Dinner with friends' },
  { id: 't8', title: 'Movie Tickets', categoryId: 'entertainment', category: 'Entertainment', amount: 600, type: 'expense', date: dateDaysAgo(9), note: 'Weekend movie' },
  { id: 't9', title: 'Pharmacy', categoryId: 'health', category: 'Health', amount: 430, type: 'expense', date: dateDaysAgo(12), note: 'Medicine' },
  { id: 't10', title: 'Bus Pass', categoryId: 'transport', category: 'Transport', amount: 900, type: 'expense', date: dateDaysAgo(40), note: 'Monthly pass' },
  { id: 't11', title: 'Consulting', categoryId: 'income', category: 'Freelance', amount: 3000, type: 'income', date: dateDaysAgo(45), note: 'Consulting project' },
  { id: 't12', title: 'Groceries', categoryId: 'food', category: 'Food & Dining', amount: 980, type: 'expense', date: dateDaysAgo(75), note: 'Monthly groceries' }
];
