export const categories = [
  { id: 'food', name: 'Food & Dining', icon: '🍜', color: '#F59E0B', budget: 8000 },
  { id: 'shopping', name: 'Shopping', icon: '🛍️', color: '#8B5CF6', budget: 5000 },
  { id: 'transport', name: 'Transport', icon: '🚕', color: '#3B82F6', budget: 3000 },
  { id: 'bills', name: 'Bills & Utilities', icon: '💡', color: '#14B8A6', budget: 4000 },
  { id: 'health', name: 'Health', icon: '💊', color: '#EC4899', budget: 2500 },
  { id: 'entertainment', name: 'Entertainment', icon: '🎬', color: '#F97316', budget: 2000 }
];
