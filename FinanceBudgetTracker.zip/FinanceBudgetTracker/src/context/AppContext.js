import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { initialTransactions } from '../data/sampleTransactions';

const AppContext = createContext(null);
const STORAGE_KEY = 'finance-budget-tracker-v1';

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState(initialTransactions);
  const [profile, setProfile] = useState({ name: 'Arun Kumar', email: 'arun@example.com', phone: '9876543210' });
  const [alert, setAlert] = useState('');
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const data = JSON.parse(raw);
          if (data.transactions) setTransactions(data.transactions);
          if (data.profile) setProfile(data.profile);
        }
      } catch (e) {
        console.warn('Could not load saved demo data', e);
      } finally {
        setHydrated(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({ transactions, profile })).catch(() => {});
  }, [transactions, profile, hydrated]);

  const notify = (message) => {
    setAlert(message);
    setTimeout(() => setAlert(current => current === message ? '' : current), 2800);
  };

  const signIn = ({ role, email, name }) => {
    const resolvedRole = role === 'Admin' ? 'Admin' : 'Customer';
    setUser({ role: resolvedRole, email: email || (resolvedRole === 'Admin' ? 'admin@demo.com' : profile.email), name: name || (resolvedRole === 'Admin' ? 'Admin' : profile.name) });
    notify(`Welcome ${name || (resolvedRole === 'Admin' ? 'Admin' : profile.name)}!`);
  };

  const signOut = () => {
    setUser(null);
    setAlert('');
  };

  const addTransaction = (transaction) => {
    const newItem = { ...transaction, id: `t${Date.now()}` };
    setTransactions(prev => [newItem, ...prev]);
    notify(`${newItem.type === 'income' ? 'Income' : 'Expense'} of ₹${Number(newItem.amount).toLocaleString('en-IN')} added successfully.`);
  };

  const updateTransaction = (id, updates) => {
    setTransactions(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
    notify('Your transaction was updated successfully.');
  };

  const saveProfile = (newProfile) => {
    setProfile(newProfile);
    notify(`Profile updated successfully, ${newProfile.name}.`);
  };

  const value = useMemo(() => ({
    user, signIn, signOut, transactions, addTransaction, updateTransaction,
    profile, saveProfile, alert, notify
  }), [user, transactions, profile, alert]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error('useApp must be used inside AppProvider');
  return value;
}
