import React from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, ScrollView } from 'react-native';
import { colors } from '../theme/colors';

export function Screen({ children, scroll = true, style }) {
  const content = <View style={[styles.screen, style]}>{children}</View>;
  return scroll ? <ScrollView style={styles.scroll} contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">{content}</ScrollView> : content;
}

export function Heading({ title, subtitle, right }) {
  return <View style={styles.headingRow}><View style={{ flex: 1 }}><Text style={styles.heading}>{title}</Text>{subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}</View>{right}</View>;
}

export function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Button({ title, onPress, variant = 'primary', style, disabled }) {
  return <TouchableOpacity activeOpacity={0.8} disabled={disabled} onPress={onPress} style={[styles.button, variant === 'secondary' && styles.secondaryButton, variant === 'danger' && styles.dangerButton, disabled && { opacity: 0.5 }, style]}><Text style={[styles.buttonText, variant === 'secondary' && styles.secondaryButtonText]}>{title}</Text></TouchableOpacity>;
}

export function Field({ label, value, onChangeText, placeholder, keyboardType, secureTextEntry, error, multiline }) {
  return <View style={styles.fieldWrap}><Text style={styles.label}>{label}</Text><TextInput value={value} onChangeText={onChangeText} placeholder={placeholder || label} placeholderTextColor="#A5A9BA" keyboardType={keyboardType || 'default'} secureTextEntry={secureTextEntry} multiline={multiline} style={[styles.input, multiline && { height: 90, textAlignVertical: 'top' }, error && { borderColor: colors.red }]} />{error ? <Text style={styles.error}>{error}</Text> : null}</View>;
}

export function Pill({ label, active, onPress }) {
  return <TouchableOpacity onPress={onPress} style={[styles.pill, active && styles.pillActive]}><Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text></TouchableOpacity>;
}

export function EmptyState({ title, subtitle }) {
  return <View style={styles.empty}><Text style={{ fontSize: 30 }}>📭</Text><Text style={styles.emptyTitle}>{title}</Text><Text style={styles.subtitle}>{subtitle}</Text></View>;
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: colors.background },
  scrollContent: { flexGrow: 1, paddingBottom: 28 },
  screen: { flex: 1, paddingHorizontal: 20, paddingTop: 18, gap: 16 },
  headingRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 2 },
  heading: { color: colors.text, fontSize: 25, fontWeight: '800' },
  subtitle: { color: colors.muted, fontSize: 13, marginTop: 4, lineHeight: 19 },
  card: { backgroundColor: colors.surface, borderRadius: 20, padding: 16, borderWidth: 1, borderColor: '#F0F1F6', gap: 10 },
  button: { backgroundColor: colors.primary, borderRadius: 13, minHeight: 48, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
  secondaryButton: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
  dangerButton: { backgroundColor: colors.red },
  buttonText: { color: '#FFFFFF', fontWeight: '700', fontSize: 15 },
  secondaryButtonText: { color: colors.text },
  fieldWrap: { gap: 6, marginBottom: 10 },
  label: { color: colors.text, fontSize: 13, fontWeight: '700' },
  input: { minHeight: 48, borderRadius: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: '#FFFFFF', paddingHorizontal: 13, color: colors.text, fontSize: 15 },
  error: { color: colors.red, fontSize: 12 },
  pill: { paddingHorizontal: 15, paddingVertical: 10, borderRadius: 20, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: colors.border },
  pillActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  pillText: { color: colors.muted, fontWeight: '600', fontSize: 13 },
  pillTextActive: { color: '#FFFFFF' },
  empty: { padding: 28, alignItems: 'center', gap: 8 },
  emptyTitle: { color: colors.text, fontWeight: '800', fontSize: 16 }
});
