import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { useApp } from '../context/AppContext';

export default function AlertBanner() {
  const { alert } = useApp();
  if (!alert) return null;
  return <View accessibilityRole="alert" style={styles.banner}><Text style={styles.icon}>✓</Text><Text style={styles.text}>{alert}</Text></View>;
}
const styles = StyleSheet.create({
  banner: { marginHorizontal: 20, marginTop: 8, padding: 12, borderRadius: 12, backgroundColor: '#E4F8F0', flexDirection: 'row', alignItems: 'center', gap: 9 },
  icon: { color: '#087A52', fontWeight: '900', fontSize: 16 },
  text: { color: '#087A52', fontSize: 13, fontWeight: '600', flex: 1 }
});
