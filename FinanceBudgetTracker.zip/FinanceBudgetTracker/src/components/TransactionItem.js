import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { money } from '../utils/calculations';

export default function TransactionItem({ item }) {
  const income = item.type === 'income';
  const date = new Date(`${item.date}T12:00:00`).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
  return <View style={styles.row}>
    <View style={[styles.icon, { backgroundColor: income ? colors.greenLight : colors.purpleLight }]}><Text style={{ fontSize: 20 }}>{income ? '↙️' : '↗️'}</Text></View>
    <View style={{ flex: 1, gap: 4 }}><Text style={styles.title}>{item.title}</Text><Text style={styles.sub}>{item.category} · {date}</Text></View>
    <Text style={[styles.amount, { color: income ? colors.green : colors.text }]}>{income ? '+' : '−'}{money(item.amount)}</Text>
  </View>;
}
const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F0F1F6' },
  icon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  title: { fontWeight: '700', color: colors.text, fontSize: 14 },
  sub: { color: colors.muted, fontSize: 12 },
  amount: { fontWeight: '800', fontSize: 13 }
});
